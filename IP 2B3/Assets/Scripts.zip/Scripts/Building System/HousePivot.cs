﻿using B3.GameStateSystem;
using B3.PlayerSystem;
using UnityEngine;

namespace B3.BuildingSystem
{
    public class HousePivot : MonoBehaviour
    {
        public PlayerBase Owner { get; private set; }
    }
}