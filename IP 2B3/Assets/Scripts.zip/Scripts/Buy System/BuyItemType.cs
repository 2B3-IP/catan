﻿namespace B3.BuySystem
{
    public enum BuyItemType
    {
        House,
        Road,
        City,
        DevelopmentCard
    }
}