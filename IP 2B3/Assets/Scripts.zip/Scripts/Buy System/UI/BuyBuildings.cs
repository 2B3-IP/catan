using B3.BuySystem;
using B3.PlayerSystem;
using NaughtyAttributes;
using UnityEngine;

public class BuyBuildings : MonoBehaviour
{
    public PlayerBase humanPlayer;
    [SerializeField] private BuyController buyController;

    [Button]
    public void BuyHouse()
    {
           
    }

    [Button]
    public void BuyRoad()
    {

    }

    [Button]
    public void BuyCity()
    {

    }
}
