﻿namespace B3.PlayerBuffSystem
{
    public enum PlayerBuff
    {
        Trade4_1 = 0,
        Trade3_1 = 1,
	    Trade2_1 = 2
    }
}