using UnityEngine;

public class Coord : MonoBehaviour
{
    public int x;
    public int y;
}
